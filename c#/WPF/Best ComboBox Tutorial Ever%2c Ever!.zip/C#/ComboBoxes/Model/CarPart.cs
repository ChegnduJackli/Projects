﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ComboBoxes.Model
{
    public class CarPart
    {
        public string PartID { get; set; }
        public string PartName { get; set; }
    }
}
